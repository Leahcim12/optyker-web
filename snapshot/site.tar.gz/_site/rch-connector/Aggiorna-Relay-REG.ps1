param(
  [string]$PrinterIp='192.168.1.10',
  [int]$Port=8765,
  [switch]$NoPause
)

$ErrorActionPreference='Stop'
trap {
  $m=if($_.Exception -and $_.Exception.Message){$_.Exception.Message}else{[string]$_}
  Write-Host ''
  Write-Host 'ERRORE AGGIORNAMENTO CLOUD RELAY RCH' -ForegroundColor Red
  Write-Host $m -ForegroundColor Red
  Write-Host ''
  Write-Host 'Il connettore fiscale NON e stato modificato. Nessuna chiusura e nessuno scontrino sono stati eseguiti.' -ForegroundColor Yellow
  if(-not $NoPause){$null=Read-Host 'Premi INVIO per chiudere'}
  exit 1
}

$base=Join-Path $env:LOCALAPPDATA 'OptykerRCH'
$worker=Join-Path $base 'rch-optyker-cloud-worker.ps1'
$config=Join-Path $base 'cloud-relay.json'
$connector=Join-Path $base 'rch-optyker-connector.ps1'
$candidate=Join-Path $base 'rch-optyker-cloud-worker.download.ps1'
$source='https://raw.githubusercontent.com/Leahcim12/optyker-web/main/rch-connector/rch-optyker-cloud-worker.ps1'

if(-not (Test-Path -LiteralPath $connector -PathType Leaf)){throw 'Connettore fiscale Optyker non trovato. Usa prima l installazione completa.'}
if(-not (Test-Path -LiteralPath $config -PathType Leaf)){throw 'Cloud Relay non ancora associato a questo PC. Usa prima l installazione completa.'}

Write-Host ''
Write-Host 'Optyker RCH - aggiornamento SOLO Cloud Relay' -ForegroundColor Cyan
Write-Host 'Il connettore fiscale e la RCH non verranno modificati durante l aggiornamento.' -ForegroundColor DarkGray
Write-Host 'Download Cloud Relay 2.3 (chiusura verificata e ritorno automatico in REG)...'

Invoke-WebRequest -UseBasicParsing -Uri $source -OutFile $candidate -TimeoutSec 60
$tokens=$null;$errors=$null
[void][System.Management.Automation.Language.Parser]::ParseFile($candidate,[ref]$tokens,[ref]$errors)
$text=Get-Content -Raw -LiteralPath $candidate
if($errors.Count -gt 0 -or $text -notmatch '2\.2-daily-closure' -or $text -notmatch 'Close-DailyManual' -or $text -notmatch "'=C10'" -or $text -notmatch 'Restore-RegManual'){
  Remove-Item -LiteralPath $candidate -Force -ErrorAction SilentlyContinue
  throw 'Cloud Relay scaricato non valido. Nessuna modifica applicata.'
}

$revision=if($text -match "\`$WorkerRevision='([^']+)'"){$Matches[1]}else{'2.2'}
Write-Host ('Componente verificato. Revisione: '+$revision) -ForegroundColor Green
if(Test-Path -LiteralPath $worker -PathType Leaf){Copy-Item -LiteralPath $worker -Destination ($worker+'.previous') -Force}

# Stop ONLY the cloud worker. Never stop the fiscal connector.
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -like '*rch-optyker-cloud-worker.ps1*' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

Move-Item -LiteralPath $candidate -Destination $worker -Force
$ps=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
$args='-NoLogo -NoProfile -ExecutionPolicy Bypass -File "'+$worker+'" -PrinterIp "'+$PrinterIp+'" -Port '+$Port
Start-Process -FilePath $ps -ArgumentList $args -WorkingDirectory $base -WindowStyle Hidden
Start-Sleep -Seconds 4

$running=@(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like '*rch-optyker-cloud-worker.ps1*' })
if($running.Count -lt 1){throw 'Il Cloud Relay aggiornato non risulta avviato. La copia precedente e disponibile come .previous.'}

Write-Host ''
Write-Host 'AGGIORNAMENTO COMPLETATO.' -ForegroundColor Green
Write-Host ('Cloud Relay: 2.2-daily-closure, revisione '+$revision) -ForegroundColor Green
Write-Host 'Il connettore fiscale NON e stato toccato.' -ForegroundColor Cyan
Write-Host 'Chiusura RCH: parte solo quando confermi Chiudi cassa in Optyker.' -ForegroundColor Cyan
Write-Host 'Dopo la chiusura, e ogni volta che la RCH resta ferma in Z, Optyker la riporta in REG da solo (solo comando =C1).' -ForegroundColor Cyan
Write-Host 'Per disattivare il ritorno automatico crea il file auto-reg-disabled nella cartella OptykerRCH.' -ForegroundColor DarkGray
Write-Host 'Nessuna chiusura fiscale e nessuno scontrino sono stati eseguiti durante questo aggiornamento.' -ForegroundColor DarkGray
if(-not $NoPause){$null=Read-Host 'Premi INVIO per terminare'}
